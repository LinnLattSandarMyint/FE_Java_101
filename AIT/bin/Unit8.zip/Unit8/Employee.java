package Unit8;

public class Employee {
	private int empNum;
	private double empSalary;
	public int getEmpNum()
	{
	return empNum;
	}
	public void setEmpNum(int num)
	{
	empNum = num;
	}
	public double getEmpSal()
	{
	return empSalary;
	}
	public void setEmpSal(double sal)
	{
	empSalary = sal;
	}

}

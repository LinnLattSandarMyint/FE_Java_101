package Unit8;

public class First1 {
	public static void main(String[] args) 
	{
	Second.nameAndAddress();
	System.out.println("First Java Program");
	}
	}
	class Second 
	{
	public static void nameAndAddress()
	{
	System.out.println("AIT Computer");
	System.out.println("Natogyi, Mandalay, Myanmar");
	}
}

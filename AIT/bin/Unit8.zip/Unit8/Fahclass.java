package Unit8;

public class Fahclass {
	public static void FtoC (double F)
	{
	double C;
	C = (F-32) * (5.0/9);
	System.out.println("Centigrade Degree: " + C);
	}
}

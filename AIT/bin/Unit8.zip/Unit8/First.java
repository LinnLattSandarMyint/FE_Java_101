package Unit8;

public class First {
	public static void main(String[] args) 
	{
	nameAndAddress();
	System.out.println("First Java Program");
	}
	public static void nameAndAddress()
	{
	System.out.println("AIT Computer");
	System.out.println("Natogyi, Mandalay, Myanmar");
	}
}

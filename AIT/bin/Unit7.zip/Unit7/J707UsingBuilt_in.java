package Unit7;

public class J707UsingBuilt_in {
	public static void main(String[] args) { 
		 double result = Math.pow(2, 5); 
		 System.out.println(result); 
		 }
}

package Unit6;

public class J6Changecase {
 public static void main (String args[]) {
	 String w1="ait computer";
	 String w2="ONLINE TRAINING WEBSITE";
	  String r1,r2;
	  r1=w1.toUpperCase();
	  r2=w2.toLowerCase();
	  System.out.println("Change to Upper Case");
	  System.out.println(r1);
	  System.out.println("Change to Lower Case");
	  System.out.println(r2);
 }
}

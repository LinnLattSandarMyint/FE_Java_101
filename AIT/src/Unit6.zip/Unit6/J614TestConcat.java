package Unit6;

public class J614TestConcat {
public static void main(String[] args) {
	String first="Lin";
	
	String second="Let";
	System.out.println(first.concat(second));
	System.out.println("Sandar".concat("Myint"));
	int r=first.compareTo(second);
	System.out.println(r);
}
}
